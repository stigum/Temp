#pragma once
#include "Qrice.h"
#include <vector>
namespace Anon {
	class OrderManager
	{
	private:
		static OrderManager *_orderManager;
	public:
		OrderManager * Instance();
		bool SendOrder(string b, string s, vector<Qrice> buylist, vector<Qrice> selllist);
	};
}