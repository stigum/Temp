#pragma once

#ifndef SIDE_H_
#define SIDE_H_

namespace Anon {

	enum Side
	{
		Buy,
		Sell
	};

}

#endif
