#include "OrderManager.h"

namespace Anon {
	// necessary to define storage  for linker
	// consider putting all statics in a single file
	OrderManager * OrderManager::_orderManager = 0;
	OrderManager *OrderManager::Instance()
	{
		if (_orderManager == 0)
			_orderManager = new OrderManager();
		return _orderManager;
	}

	bool OrderManager::SendOrder(string buyticker, string sellticker, vector<Qrice> buylist, vector<Qrice> selllist)
	{
		return true;
	}
}