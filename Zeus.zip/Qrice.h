#pragma once
#ifndef QRICE_H_
#define QRICE_H_

#include<iostream>
#include<string>
#include "../Base/Macros.h"

using namespace std;
namespace Anon
{

	struct Qrice
	{
	private:
		//bool Equals(Qrice other);

	public:
		Qrice(Decimal p, int q);
		int Quantity;
		Decimal Price;
		string ToString();

	};
}

#endif // !QRICE_H_
