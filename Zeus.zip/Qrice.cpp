#include "Qrice.h"

namespace Anon {
	Qrice::Qrice(Decimal p, int q)
	{
		Quantity = q;
		Price = p;

	}


	string Qrice::ToString()
	{

		//return dec::toString(Price) + " for " + dec::toString(Quantity);
		return toString(Price) + " for " +std::to_string(Quantity);
	}

}